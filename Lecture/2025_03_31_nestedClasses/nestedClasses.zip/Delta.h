// Delta.h
#include "Charlie.h"

class Delta {
public:
    Delta();
    int doubleX();
private:
    Charlie c;
};
