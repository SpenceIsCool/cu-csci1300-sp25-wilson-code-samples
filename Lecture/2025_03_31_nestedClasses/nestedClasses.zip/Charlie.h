// Charlie.h
class Charlie {
public:
    Charlie();
    int getX();
    void setX( int y );
private:
    int x;
};
