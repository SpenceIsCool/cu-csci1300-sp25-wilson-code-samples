// main.cpp
#include<iostream>
#include "Delta.h"
using namespace std;

int main()
{
    Delta d = Delta();
    cout << d.doubleX() << endl;
    cout << d.doubleX() << endl;
    cout << d.doubleX() << endl;
    cout << d.doubleX() << endl;
    return 0;
}
