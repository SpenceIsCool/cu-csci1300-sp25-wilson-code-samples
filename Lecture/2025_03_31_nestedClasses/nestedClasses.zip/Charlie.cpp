// Charlie.cpp
#include "Charlie.h"

Charlie::Charlie()
{
    x = 1;
}


int Charlie::getX()
{
    return x;
}

void Charlie::setX( int y )
{
    x = y;
}

    
