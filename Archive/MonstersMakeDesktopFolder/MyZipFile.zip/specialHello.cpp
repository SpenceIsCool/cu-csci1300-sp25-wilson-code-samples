#include<iostream>
using namespace std; // no longer need `std::`

int main() {
    cout << endl;
    cout << endl;
    cout << endl;
    cout << "Hello, World! 🤯🤯🤯🤯🤯🤯🤯" << endl;
    cout << endl;
    cout << endl;
    cout << endl;
}
